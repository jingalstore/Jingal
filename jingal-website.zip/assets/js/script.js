const products = [
  {
    name: "Funky Bluetooth Speaker",
    description: "Loud, compact, and colorful.",
    link: "https://www.amazon.in/dp/B09XYZ123",
  },
  {
    name: "Glow-in-the-dark Earphones",
    description: "Perfect for night vibes.",
    link: "https://www.flipkart.com/p/itm09abc456",
  }
];

const productList = document.getElementById("product-list");
products.forEach(product => {
  const div = document.createElement("div");
  div.className = "product";
  div.innerHTML = `<h3>${product.name}</h3><p>${product.description}</p><a href='${product.link}' target='_blank'>Buy Now</a>`;
  productList.appendChild(div);
});